import { InMemoryDbService } from 'angular-in-memory-web-api';
export class InMemoryDataService implements InMemoryDbService {
  createDb() {
    const heroes = [
      { id: 10,  name: 'Осадчий Л.А.' },
      { id: 11, name: 'Виштак В.А.' },
      { id: 12, name: 'Шарепо А.П.' },
      { id: 13, name: 'Казимир А.Г.' },
      { id: 14, name: 'Кривобок А.С.' },
      { id: 15, name: 'Кассаба А.Х.' },
      { id: 16, name: 'Хачовник О.К.' },
      { id: 17, name: 'Вишневск А.Н.' },
      { id: 18, name: 'Чижов А.О' },
      { id: 19, name: 'Амурбек Н.Н.' },
      { id: 20, name: 'Шевченко Н.А.' }
    ];
    return {heroes};
  }
}
